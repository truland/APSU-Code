/*
random_gen.hpp
*********************************************************
void rand_reset()
uint64_t B64MWC()
void rand_seed()
void rand_seed_manual(uint64_t seed)
uint64_t get_rand()
void rand_warmup(int iterations)
void get_rand(double& num)
*********************************************************
*/

#include<iostream>
#include<fstream>
#include<iomanip>
#include<cmath>
#include<complex>
#include<string>
#include<vector>
#include<ctime>
#include "random_gen.hpp"

using namespace std;

const int MAX_X=50;
const int MAX_Y=50;
const int MAX_T=2500;
const int MAX_P=1000000;
const double MAG_MOM=5.788e-5;
const double BOLTZ=8.617e-5;
const double MAG_FIELD=20.0;
const double B=5.0;
const double MAX_J=0.04;
const double MIN_J=-0.04;
const double J=0.004;

int main()
{
	rand_seed_manual(time(nullptr));

	int i;
	int j;
	int count=0;
	double k;
	double l;

	int **Iron=new int*[MAX_Y];
	for(i=0; i<MAX_Y; i++)
		Iron[i]=new int[MAX_X];
		
	double curr_mag=0.0;
	double curr_energy=0.0;

	double mag_sum=0.0;
	double mag_2_sum=0.0;
	double energy_sum=0.0;
	double energy_2_sum=0.0;

	double randx;
	double randy;
	double randprob;
	double prob;
	
	double de;
	double dmag;
	
	int currx;
	int curry;
	int x1;
	int x2;
	int y1;
	int y2;

	ofstream expect_energy;
	ofstream expect_2_energy;
	ofstream expect_mag;
	ofstream expect_2_mag;
	ofstream spin_state;
	ofstream mag_file;

	expect_energy.open("Energy.csv");
	expect_2_energy.open("Energy2.csv");
	expect_mag.open("Mag.csv");
	expect_2_mag.open("Mag2.csv");
for(k=MIN_J; k<=(MAX_J+J); k+=J)
{
	for(l=0; l<=(MAG_FIELD); l+=B)
	{
		curr_mag=0.0;
		curr_energy=0.0;

		for(i=0; i<MAX_Y; i++)
			for(j=0; j<MAX_X; j++)
				Iron[i][j]=1;

		for(i=0; i<MAX_Y; i++)
		{
			for(j=0; j<MAX_X; j++)
			{
				curr_mag+=Iron[i][j];
			}
		}

		for(i=1; i<MAX_Y-1; i++)
		{
			for(j=1; j<MAX_X-1; j++)
			{
				curr_energy+=(-Iron[i][j]*k*(Iron[i-1][j-1]+Iron[i+1][j-1]+Iron[i+1][j+1]+Iron[i-1][j+1]));
				curr_energy+=(-Iron[i][j]*l*MAG_MOM);
			}
		}

		for(i=0; i<=MAX_T; i++)
		{
			energy_sum=0.0;
			energy_2_sum=0.0;
			mag_sum=0.0;
			mag_2_sum=0.0;
			for(j=0; j<MAX_P; j++)
			{
				get_rand(randx);
				get_rand(randy);
				
				currx=floor(randx*(MAX_X));		
				curry=floor(randy*(MAX_Y));		
				Iron[curry][currx]*=-1;
	
				x1=currx-1;
				x2=currx+1;
				y1=curry-1;
				y2=curry+1;
	
				if(x1==-1)
					x1=(MAX_X-1);
				if(x2==MAX_X)
					x2=0;
				if(y1==-1)
					y1=(MAX_Y-1);
				if(y2==MAX_Y)
					y2=0;
	
				
				de=((-2.0*l*Iron[curry][currx]*MAG_MOM)+
				(-2.0*k*Iron[curry][currx]*(Iron[y1][x1]+Iron[y2][x1]+Iron[y1][x2]+Iron[y2][x2])));
				dmag=2.0*Iron[curry][currx];
	
				get_rand(randprob);
				prob=exp((-de)/(BOLTZ*static_cast<double>(i)));
				if(randprob<prob)
				{
					curr_energy+=de;
					curr_mag+=dmag;
				}else{
					Iron[curry][currx]*=-1;
				}
	
				energy_sum+=curr_energy;
				energy_2_sum+=(curr_energy*curr_energy);
				mag_sum+=curr_mag;
				mag_2_sum+=(curr_mag*curr_mag);
			}
		
			count+=2;
			expect_energy << scientific << (energy_sum/static_cast<double>(MAX_P)) << endl;
			expect_2_energy << scientific << (energy_2_sum/static_cast<double>(MAX_P)) << endl;
			expect_mag << scientific << (mag_sum/static_cast<double>(MAX_P)) << endl;
			expect_2_mag << scientific << (mag_2_sum/static_cast<double>(MAX_P)) << endl;
		}
		cout << curr_mag << " " << " " << curr_energy << " " << k << " " << l << endl;
	}
}	
	for(i=0; i<MAX_X; i++)
		delete[] Iron[i];
	delete [] Iron;

	expect_energy.close();
	expect_2_energy.close();
	expect_mag.close();
	expect_2_mag.close();

	return 0;
}
