#ifndef rand_gen
#define rand_gen
/*
THOMAS RULAND
*/
#include<iostream>
#include<fstream>
#include<iomanip>
#include<cmath>
#include<complex>
#include<omp.h>
#include<vector>
#include<ctime>
#include<cstdlib>
#include<cstdint>
#include<ctime>

/*THIS CODE WAS BORROWED FRO J. Oelgoetz's pi.cpp from elearn.apsu.edu*/
/* the borrowed code starts here*/
#define QSIZE 0x200000
#define CNG (cng = 6906969069ULL * cng + 13579)
#define XS (xs ^= (xs << 13), xs ^= (xs >> 17), xs ^= (xs << 43))
#define KISS (B64MWC() + CNG + XS)

static uint64_t QARY[QSIZE];
static int jj;
static uint64_t carry;
static uint64_t xs;
static uint64_t cng;

void rand_reset()
{
	jj=QSIZE-1;
	carry=0;
    	xs = 362436069362436069ULL;
	cng = 123456789987654321ULL; /* use this as the seed */
}

uint64_t B64MWC()
{
	uint64_t tt;
	uint64_t xx;
	jj=(jj+1)&(QSIZE-1);
	xx=QARY[jj];
	tt=(xx<<28)+carry;
	carry=(xx>>36)-(tt-xx);
	return (QARY[jj]=tt-xx);
}

void rand_seed()
{
	for(uint64_t ii=0; ii<QSIZE; ii++)
	{
		QARY[ii]=CNG+XS; //SEEDING QARY
	}
}

void rand_seed_manual(uint64_t seed)
{
	cng^=seed;
	xs^=cng;
	rand_seed();
}

//GENERATE PSUEDORAND
uint64_t get_rand()
{
	return KISS;
}

void rand_warmup(int iterations)
{
	for(int ii=0; ii<iterations; ii++)
	{
		get_rand();
	}
}

void get_rand(double& num)
{
	uint64_t num_two;
	double const den=pow(2,64)*(1.0000001);
	num_two=get_rand();
	num=num_two;
	num=num/den;
}
/*BORROWED CODE ENDS HERE*/
#endif
