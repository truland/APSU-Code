/*
PROGRAM TO SOLVE FOR THE EIGENVALUES OF THE ENERGY IN A PARABOLIC INFINITE WELL
*/
#include<iostream>
#include<fstream>
#include<iomanip>
#include<cmath>
#include<complex>
#include<gmpxx.h>
#include<omp.h>
#include<string>
#include<vector>
#include<ctime>

using namespace std;

const long double pi=4.0*atan(1.0);

int main()
{

	ifstream normalizing;
	normalizing.open("eigenvalues.csv");
	int MAX;
	normalizing >> MAX;
	normalizing.close();
	double *curr_state=new double[MAX];
	double *squared_state=new double[MAX];
	double sum=0.0;
	double constant=0.0;
	double width=(1.0e-9/(static_cast<double>(MAX)));
	ofstream square_ground;
	ofstream probdens;

	normalizing.open("groundstate.csv");
	for(int i=0; i<MAX; i++)
	{
		normalizing >> curr_state[i];
		squared_state[i]=(curr_state[i]*curr_state[i]);
	}
	normalizing.close();
	for(int i=0; i<MAX; i++)
	{
		sum+=squared_state[i];
	}
	sum*=width;
	constant=1.0/(sqrt(sum));
	square_ground.open("normalized_ground.csv");
	probdens.open("squared_ground.csv");
	for(int i=0; i<MAX; i++)
	{
		square_ground << fixed << setprecision(17) << constant*(squared_state[i]/curr_state[i]) << endl;
		probdens << fixed << setprecision(17) << (constant*constant*squared_state[i]) << endl;
	}
	square_ground.close();
	probdens.close();

	sum=0.0;
	constant=0.0;
	normalizing.open("firststate.csv");
	for(int i=0; i<MAX; i++)
	{
		normalizing >> curr_state[i];
		squared_state[i]=(curr_state[i]*curr_state[i]);
	}
	normalizing.close();
	for(int i=0; i<MAX; i++)
	{
		sum+=squared_state[i];
	}
	sum*=width;
	constant=1.0/(sqrt(sum));
	square_ground.open("normalized_first.csv");
	probdens.open("squared_first.csv");
	for(int i=0; i<MAX; i++)
	{
		square_ground << fixed << setprecision(17) << constant*(squared_state[i]/curr_state[i]) << endl;
		probdens << fixed << setprecision(17) << (constant*constant*squared_state[i]) << endl;
	}
	square_ground.close();
	probdens.close();

	sum=0.0;
	constant=0.0;
	normalizing.open("secondstate.csv");
	for(int i=0; i<MAX; i++)
	{
		normalizing >> curr_state[i];
		squared_state[i]=(curr_state[i]*curr_state[i]);
	}
	normalizing.close();
	for(int i=0; i<MAX; i++)
	{
		sum+=squared_state[i];
	}
	sum*=width;
	constant=1.0/(sqrt(sum));
	square_ground.open("normalized_second.csv");
	probdens.open("squared_second.csv");
	for(int i=0; i<MAX; i++)
	{
		square_ground << fixed << setprecision(17) << constant*(squared_state[i]/curr_state[i]) << endl;
		probdens << fixed << setprecision(17) << (constant*constant*squared_state[i]) << endl;
	}
	square_ground.close();
	probdens.close();

	sum=0.0;
	constant=0.0;
	normalizing.open("thirdstate.csv");
	for(int i=0; i<MAX; i++)
	{
		normalizing >> curr_state[i];
		squared_state[i]=(curr_state[i]*curr_state[i]);
	}
	normalizing.close();
	for(int i=0; i<MAX; i++)
	{
		sum+=squared_state[i];
	}
	sum*=width;
	constant=1.0/(sqrt(sum));
	square_ground.open("normalized_third.csv");
	probdens.open("squared_third.csv");
	for(int i=0; i<MAX; i++)
	{
		square_ground << fixed << setprecision(17) << constant*(squared_state[i]/curr_state[i]) << endl;
		probdens << fixed << setprecision(17) << (constant*constant*squared_state[i]) << endl;
	}
	square_ground.close();
	probdens.close();
	
	square_ground.open("squarewellground.csv");
	probdens.open("squared_square_ground.csv");
	for(int i=1; i<=MAX; i++)
	{
		square_ground << fixed << setprecision(17) << (sqrt(2.0/1.0e-9)*sin((pi*(i*width))/(1.0e-9))) << endl;
		probdens << fixed << setprecision(17) << ((2.0/1.0e-9)*sin((pi*(i*width))/(1.0e-9))*sin((pi*(i*width))/(1.0e-9))) << endl;
	}
	square_ground.close();
	probdens.close();

	square_ground.open("squarewellfirst.csv");
	probdens.open("squared_square_first.csv");
	for(int i=1; i<=MAX; i++)
	{
		square_ground << fixed << setprecision(17) << (sqrt(2.0/1.0e-9)*sin((2.0*pi*(i*width))/(1.0e-9))) << endl;
		probdens << fixed << setprecision(17) << ((2.0/1.0e-9)*sin((2.0*pi*(i*width))/(1.0e-9))*sin((2.0*pi*(i*width))/(1.0e-9))) << endl;
	}
	square_ground.close();
	probdens.close();

	square_ground.open("squarewellsecond.csv");
	for(int i=1; i<=MAX; i++)
	{
		square_ground << fixed << setprecision(17) << (sqrt(2.0/1.0e-9)*sin((3.0*pi*(i*width))/(1.0e-9))) << endl;
	}
	square_ground.close();

	square_ground.open("squarewellthird.csv");
	for(int i=1; i<=MAX; i++)
	{
		square_ground << fixed << setprecision(17) << (sqrt(2.0/1.0e-9)*sin((4.0*pi*(i*width))/(1.0e-9))) << endl;
	}
	square_ground.close();

	return 0;
}
