/*
PROGRAM TO SOLVE FOR THE EIGENVALUES OF THE ENERGY IN A PARABOLIC INFINITE WELL
*/
#include<iostream>
#include<fstream>
#include<iomanip>
#include<cmath>
#include<complex>
#include<gmpxx.h>
#include<omp.h>
#include<string>
#include<vector>
#include<ctime>

using namespace std;

const long double pi=4.0*atan(1.0);

int main()
{

	int MAX;
	ifstream ergs;
	ergs.open("energies.csv");
	ergs >> MAX;
	ergs.close();
//	INPUT FILE STREAMS
	ifstream ground;//GROUND STATE
	ifstream first;//FIRST EXCITED STATE
	ifstream second;//SECOND EXCITED STATE
	ifstream third;//THIRD EXCITED STATE
	ifstream fourth;//FOURTH EXCITED STATE
	ifstream fifth;//FIFTH EXCITED STATE
//	OUTPUT FILE STREAMS
	ofstream gstate;
	ofstream state1;
	ofstream state2;
	ofstream state3;
	ofstream state4;
	ofstream state5;
	ofstream square_ground;
//	DATA ARRAYS
	long double *gs=new long double[MAX];
	long double *s1=new long double[MAX];
	long double *s2=new long double[MAX];
	long double *s3=new long double[MAX];
	long double *s4=new long double[MAX];
	long double *s5=new long double[MAX];
	long double gstemp[MAX];
	long double s1temp[MAX];
	long double s2temp[MAX];
	long double s3temp[MAX];
	long double s4temp[MAX];
	long double s5temp[MAX];
	long double maxg=0.0;
	long double max1=0.0;
	long double max2=0.0;
	long double max3=0.0;
	long double max4=0.0;
	long double max5=0.0;
	long double width=((1.0e-9)/(MAX));
	long double integralsum=0.0;
	long double A=0.0;
	long double temp=0.0;
//	OPENING DATA FILES
	ground.open("groundstate.csv");
	first.open("firststate.csv");
	second.open("secondstate.csv");
	third.open("thirdstate.csv");
	fourth.open("fourthstate.csv");
	fifth.open("fifthstate.csv");
//	READING IN DATA FILES
	for(int i=0; i<MAX; i++)
	{
		ground >> gs[i];//GROUND STATE
		first >> s1[i];//FIRST STATE
		second >> s2[i];//SECOND STATE
		third >> s3[i];//THIRD STATE
		fourth >> s4[i];//FOURTH STATE
		fifth >> s5[i];//FIFTH STATE
	}
//	CLOSING ORIGINAL FILES
	ground.close();
	first.close();
	second.close();
	third.close();
	fourth.close();
	fifth.close();
//	SQUARING THE VALUES
	for(int i=0; i<MAX; i++)
	{
		temp=gs[i]*gs[i];
		gstemp[i]=gs[i];
		if(temp==0)
		{
			temp=1e-9;
			gstemp[i]=1e-9;
		}
		gs[i]=temp;

		s1temp[i]=s1[i];
		temp=s1[i]*s1[i];
		if(temp==0)
		{
			temp=1e-9;
			s1temp[i]=1e-9;
		}
		s1[i]=temp;

		s2temp[i]=s2[i];
		temp=s2[i]*s2[i];
		if(temp==0)
		{
			temp=1e-9;
			s2temp[i]=1e-9;
		}
		s2[i]=temp;

		s3temp[i]=s3[i];
		temp=s3[i]*s3[i];
		if(temp==0)
		{
			temp=1e-9;
			s3temp[i]=1e-9;
		}
		s3[i]=temp;

		s4temp[i]=s4[i];
		temp=s4[i]*s4[i];
		if(temp==0)
		{
			temp=1e-9;
			s4temp[i]=1e-9;
		}
		s4[i]=temp;

		s5temp[i]=s5[i];
		temp=s5[i]*s5[i];
		if(temp==0)
		{
			temp=1e-9;
			s5temp[i]=1e-9;
		}
		s5[i]=temp;
	}
//	NORMALIZING GROUND STATE	
	for(int i=0; i<MAX; i++)
	{
		integralsum+= gs[i]*width;
	}
	A=(sqrt(1.0/integralsum));
	for(int i=0; i<MAX; i++)
	{
		gs[i]*=A*A;
		gs[i]/=(gstemp[i]*A);
	}
//	NORMALIZING FIRST STATE
	integralsum=0.0;
	for(int i=0; i<MAX; i++)
	{
		integralsum+= s1[i]*width;
	}
	A=(sqrt(1.0/integralsum));
	for(int i=0; i<MAX; i++)
	{
		s1[i]*=(A*A);
		s1[i]/=(s1temp[i]*A);
	}
//	NORMALIZING SECOND STATE
	integralsum=0.0;
	for(int i=0; i<MAX; i++)
	{
		integralsum+= s2[i]*width;
	}
	A=(sqrt(1.0/integralsum));
	for(int i=0; i<MAX; i++)
	{
		s2[i]*=(A*A);
		s2[i]/=(s2temp[i]*A);
	}

//	NORMALIZING THIRD STATE
	integralsum=0.0;
	for(int i=0; i<MAX; i++)
	{
		integralsum+= s3[i]*width;
	}
	A=(sqrt(1.0/integralsum));
	for(int i=0; i<MAX; i++)
	{
		s3[i]*=(A*A);
		s3[i]/=(s3temp[i]*A);
	}

//	NORMALIZING FOURTH STATE
	integralsum=0.0;
	for(int i=0; i<MAX; i++)
	{
		integralsum+= s4[i]*width;
	}
	A=(sqrt(1.0/integralsum));
	for(int i=0; i<MAX; i++)
	{
		s4[i]*=(A*A);
		s4[i]/=(s4temp[i]*A);
	}

//	NORMALIZING FIFTH STATE
	integralsum=0.0;
	for(int i=0; i<MAX; i++)
	{
		integralsum+= s5[i]*width;
	}
	A=(sqrt(1.0/integralsum));
	for(int i=0; i<MAX; i++)
	{
		s5[i]*=(A*A);
		s5[i]/=(s5temp[i]*A);
	}

//	OPENING OUTPUT FILES FOR WRITING
	gstate.open("normalground.csv");
	state1.open("normalfirst.csv");
	state2.open("normalsecond.csv");
	state3.open("normalthird.csv");
	state4.open("normalfourth.csv");
	state5.open("normalfifth.csv");
//	WRITING FILES
	for(int i=0; i<MAX; i++)
	{
		gstate << gs[i] << endl;
		state1 << s1[i] << endl;
		state2 << s2[i] << endl;
		state3 << s3[i] << endl;
		state4 << s4[i] << endl;
		state5 << s5[i] << endl;
	}
//	CLOSING FILES
	gstate.close();
	state1.close();
	state2.close();
	state3.close();
	state4.close();
	state5.close();

	delete [] gs;
	delete [] s1;
	delete [] s2;
	delete [] s3;
	delete [] s4;
	delete [] s5;
	gs=s1=s2=s3=s4=s5=0;

	square_ground.open("squarewellground.csv");
	for(int i=0; i<MAX; i++)
	{
		temp=(sqrt(2.0/1.0e-9)*sin((pi*(i*width))/(1.0e-9)));
		square_ground << temp << endl;
	}
	square_ground.close();

	square_ground.open("squarewellfirst.csv");
	for(int i=0; i<MAX; i++)
	{
		temp=(sqrt(2.0/1.0e-9)*sin((2.0*pi*(i*width))/(1.0e-9)));
		square_ground << temp << endl;
	}
	square_ground.close();
	
	square_ground.open("squarewellsecond.csv");
	for(int i=0; i<MAX; i++)
	{
		temp=(sqrt(2.0/1.0e-9)*sin((3.0*pi*(i*width))/(1.0e-9)));
		square_ground << temp << endl;
	}
	square_ground.close();
	
	square_ground.open("squarewellthird.csv");
	for(int i=0; i<MAX; i++)
	{
		temp=(sqrt(2.0/1.0e-9)*sin((4.0*pi*(i*width))/(1.0e-9)));
		square_ground << temp << endl;
	}
	square_ground.close();
	
	square_ground.open("squarewellfourth.csv");
	for(int i=0; i<MAX; i++)
	{
		temp=(sqrt(2.0/1.0e-9)*sin((5.0*pi*(i*width))/(1.0e-9)));
		square_ground << temp << endl;
	}
	square_ground.close();
	
	square_ground.open("squarewellfifth.csv");
	for(int i=0; i<MAX; i++)
	{
		temp=(sqrt(2.0/1.0e-9)*sin((6.0*pi*(i*width))/(1.0e-9)));
		square_ground << temp << endl;
	}
	square_ground.close();

	return 0;
}
